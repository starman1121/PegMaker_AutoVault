import { createHashHistory } from 'history';

// A singleton history object for easy API navigation
const history = createHashHistory();
export default history;
