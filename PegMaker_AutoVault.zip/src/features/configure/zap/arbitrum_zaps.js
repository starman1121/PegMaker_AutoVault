export const arbitrumZaps = [
  {
    // Sushi
    zapAddress: '0x6D973E33af0801Af13b7939956745c72bB17aa1E',
    ammRouter: '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506',
    ammFactory: '0xc35DADB65012eC5796536bD9864eD8773aBc74C4',
    ammPairInitHash: '0xe18a34eb0e04b04f7a0ac29a6e80748dca96319b42c54d679cb821dca90c6303',
  },
];
