export const hecoZaps = [];
