export const moonriverZaps = [
  {
    // Solarbeam
    zapAddress: '0xb0F9c6FBcfE226EEAD3AE8b019ce4666cE223a78',
    ammRouter: '0xAA30eF758139ae4a7f798112902Bf6d65612045f',
    ammFactory: '0x049581aEB6Fe262727f290165C29BDAB065a1B68',
    ammPairInitHash: '0x9a100ded5f254443fbd264cb7e87831e398a8b642e061670a9bc35ba27293dbf',
  },
];
