import React from 'react';
import { StakePool } from './sections';

export default function PoolPage(props) {
  return (
    <>
      <StakePool {...props} />
    </>
  );
}
