export { default as VaultPage } from './VaultPage';
